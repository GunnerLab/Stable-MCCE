## Compute hydrogen bond network


