	include 'pointer.h'
	include 'qdiffpar5.h'
